### R code from vignette source 'KoreanProjection-vignettes.Rnw'
### Encoding: CP949

###################################################
### code chunk number 1: KoreanProjection-vignettes.Rnw:25-26
###################################################
  if(exists(".orig.enc")) options(encoding = .orig.enc)


###################################################
### code chunk number 2: chunk1
###################################################
x <- rnorm(100)
mean(x)



###################################################
### code chunk number 3: chunk2
###################################################
hist(rnorm(x))



###################################################
### code chunk number 4: sessionInfo
###################################################
toLatex(sessionInfo())



