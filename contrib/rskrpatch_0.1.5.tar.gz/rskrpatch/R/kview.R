#' kview - View in safe data include Korean Characters
#'
#' 윈도우즈상에서 구동되는 RStudio에서 한글이 포함된 자료가
#' 보여질 때 발생하는 문제를 수정해 주는 함수
#' @author 박희성\email{hspark90@@i-fam.net}
#' @export
#' @encoding utf-8
#' @param x 데이터 프레임에 기반을 둔 R 객체
#' @param title 뷰어 창의 제목 - 생략되면 x에 사용된 변수명이 제목으로 사용됨
#' @return 보이지 않는 NULL. 창을 띄우고 즉시 반환 - 창은 창의 콘트롤이나
#' 메뉴를 통해 닫을 수 있음
#' @details 윈도우즈상의 RStudio에서 \code{\link[utils:View]{View}} 함수를
#' 사용할 때 데이터의 인코딩 설정 문제로 한글이 포함된 데이터가
#' 깨져 보이는 현상이 발생한다. 본 함수는 한글이 깨어져 보이지 않도록
#' 사전에 데이터의 인코딩을 재설정하여 \code{\link[utils:View]{View}}
#' 함수를 호출해주는 래퍼함수이다.\cr
#' 단지, 한글윈도우즈상에 설치되어 작동하는 RStudio의 기능을 수정하기 위한 것임
#' @keywords data.frame
#' @keywords matrix
#' @keywords vector
#' @seealso \code{\link[utils:View]{View}}
kview <- function(x, title)
{
  if (exists("RStudio.Version")) {
    View(x, title)
  } else {
    X <- if (is.vector(x)) {
      if (is.character(x)) {
        z <- enc2utf8(x)
        Encoding(z) <- "unknown"
      } else {
        z <- x
      }
      z
    } else {
      apply(x,2,function(y) {
        if (is.character(y)) {
          z <- enc2utf8(y)
          Encoding(z) <- "unknown"
        } else {
          z <- y
        }
        return(z)
      })
    }
    if (missing(title))
      title <- deparse(substitute(x))
    View(X, title)
  }
}