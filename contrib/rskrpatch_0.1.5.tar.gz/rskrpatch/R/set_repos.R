#' repos.USGSr.github
#' 
#' USGS에서 운영하는 github의 R 프로젝트를 제공하는 리포지토리를 
#' 사용할 수 있도록 등록하거나 제거하는 함수.
#' @author 박희성\email{hspark90@@i-fam.net}
#' @encoding utf-8
#' @param on 리포지터리를 사용 가능하게 할 것인지 아닌지를 설정하는 논리변수
#' @details USGS는 github에 R 프로젝트를 공개적으로 개발하고 있음.
#' @keywords repository
#' @seealso \code{\link[rskrpatch:repos.USGSr.github]{repos.USGSr.github}}, 
#' \code{\link[rskrpatch:repos.USGSR]{repos.USGSR}},
#' \code{\link[rskrpatch:repos.kict.in]{repos.kict.in}},
#' \code{\link[rskrpatch:repos.kict.pub]{repos.kict.pub}},
#' \code{\link[rskrpatch:repos.rforge.net]{repos.rforge.net}},
#' \code{\link[rskrpatch:repos.R_Forge]{repos.R_Forge}}
repos.USGSr.github <- function(on = T) set_repos("USGSr.github", on)


#' repos.USGSR
#' 
#' USGS에서 운영하는 R 패키지 리포지토리를 
#' 사용할 수 있도록 등록하거나 제거하는 함수
#' @author 박희성\email{hspark90@@i-fam.net}
#' @encoding utf-8
#' @param on 리포지터리를 사용 가능하게 할 것인지 아닌지를 설정하는 논리변수
#' @details USGS에서 제공하는 R 패키지 리포지토리를 설정하는 함수로서
#' github에서 개발되는 R 프로젝트랑 일부 중복됨
#' @keywords repository
#' @seealso \code{\link[rskrpatch:repos.USGSr.github]{repos.USGSr.github}}, 
#' \code{\link[rskrpatch:repos.USGSR]{repos.USGSR}},
#' \code{\link[rskrpatch:repos.kict.in]{repos.kict.in}},
#' \code{\link[rskrpatch:repos.kict.pub]{repos.kict.pub}},
#' \code{\link[rskrpatch:repos.rforge.net]{repos.rforge.net}},
#' \code{\link[rskrpatch:repos.R_Forge]{repos.R_Forge}}
repos.USGSR <- function(on = T) set_repos("USGSR", on)

#' repos.kict.in
#' 
#' 한국건설기술연구원에서 개발 중인 내부용 패키지 
#' 배포 리포지터리를 등록하거나 해제하는 함수
#' @author 박희성\email{hspark90@@i-fam.net}
#' @export
#' @encoding utf-8
#' @param on 리포지터리를 사용 가능하게 할 것인지 아닌지를 설정하는 논리변수
#' @details 한국건설기술연구원에서 개발하고 있는 R 패키지 배포 리포지터리를 
#' 설정하거나 해제하는 함수
#' @keywords repository
#' @seealso \code{\link[rskrpatch:repos.USGSr.github]{repos.USGSr.github}}, 
#' \code{\link[rskrpatch:repos.USGSR]{repos.USGSR}},
#' \code{\link[rskrpatch:repos.kict.in]{repos.kict.in}},
#' \code{\link[rskrpatch:repos.kict.pub]{repos.kict.pub}},
#' \code{\link[rskrpatch:repos.rforge.net]{repos.rforge.net}},
#' \code{\link[rskrpatch:repos.R_Forge]{repos.R_Forge}}
repos.kict.in <- function(on = T) set_repos("kict.in", on)

#' repos.kict.pub
#' 
#' 한국건설기술연구원에서 개발 중인 외부용 패키지 배포
#' 리포지터리를 등록하거나 해제하는 함수
#' @author 박희성\email{hspark90@@i-fam.net}
#' @export
#' @encoding utf-8
#' @param on 리포지터리를 사용 가능하게 할 것인지 아닌지를 설정하는 논리변수
#' @details 한국건설기술연구원에서 개발하고 있는 R 패키지 배포 리포지터리를 
#' 설정하거나 해제하는 함수
#' @keywords repository
#' @seealso \code{\link[rskrpatch:repos.USGSr.github]{repos.USGSr.github}}, 
#' \code{\link[rskrpatch:repos.USGSR]{repos.USGSR}},
#' \code{\link[rskrpatch:repos.kict.in]{repos.kict.in}},
#' \code{\link[rskrpatch:repos.kict.pub]{repos.kict.pub}},
#' \code{\link[rskrpatch:repos.rforge.net]{repos.rforge.net}},
#' \code{\link[rskrpatch:repos.R_Forge]{repos.R_Forge}}
repos.kict.pub <- function(on = T) set_repos("kict.pub", on)

#' repos.rforge.net
#' 
#' rforge.net의 배포 리포지터리를 사용할 수 있도록 설정하거나
#' 해제하는 함수
#' @author 박희성\email{hspark90@@i-fam.net}
#' @export
#' @encoding utf-8
#' @param on 리포지터리를 사용 가능하게 할 것인지 아닌지를 설정하는 논리변수
#' @keywords repository
#' @seealso \code{\link[rskrpatch:repos.USGSr.github]{repos.USGSr.github}}, 
#' \code{\link[rskrpatch:repos.USGSR]{repos.USGSR}},
#' \code{\link[rskrpatch:repos.kict.in]{repos.kict.in}},
#' \code{\link[rskrpatch:repos.kict.pub]{repos.kict.pub}},
#' \code{\link[rskrpatch:repos.rforge.net]{repos.rforge.net}},
#' \code{\link[rskrpatch:repos.R_Forge]{repos.R_Forge}}
repos.rforge.net <- function(on = T) set_repos("rforge.net", on)

#' repos.R_Forge
#' 
#' R-Forge.R-project.org 에서 개발 중인 패키지 배포 리포지터리를 사용할 수 있도록
#' 설정하거나 해제하는 함수
#' @author 박희성\email{hspark90@@i-fam.net}
#' @export
#' @encoding utf-8
#' @param on 리포지터리를 사용 가능하게 할 것인지 아닌지를 설정하는 논리변수
#' @keywords repository
#' @seealso \code{\link[rskrpatch:repos.USGSr.github]{repos.USGSr.github}}, 
#' \code{\link[rskrpatch:repos.USGSR]{repos.USGSR}},
#' \code{\link[rskrpatch:repos.kict.in]{repos.kict.in}},
#' \code{\link[rskrpatch:repos.kict.pub]{repos.kict.pub}},
#' \code{\link[rskrpatch:repos.rforge.net]{repos.rforge.net}},
#' \code{\link[rskrpatch:repos.R_Forge]{repos.R_Forge}}
repos.R_Forge <- function(on = T) set_repos("R-Forge", on)


# set_repos
# 
# 지정된 이름의 리포지토리를 사용할 수 있게 하거나 사용할 수 없게 함
# @author 박희성 \email{hspark90@@i-fam.net}
# @encoding utf-8
# @param x 저장되어 있는 리포지터리 명칭
# @param on 리포지터리를 사용 가능하게 할 것인지 아닌지를 설정하는 논리변수
# @details 미리 저장된 리포지토의 설정을 하는 내부 함수
# @keywords data.frame
# @keywords matrix
# @keywords vector
# @seealso \code{\link[utils:View]{View}}
set_repos <- function(x, on=T) {
  r <- getOption("repos")
  if (on) {
    url <- .repos.base.url[x]
    if(!is.na(url) && !any(r == url)) r[x] <- url
  } else {
    r <- r[names(r) != x]
  }
  options(repos = r)
}