#' rskrpatch: Korean Help file viewing patch for RStudio
#'
#' RStudio에서 매개변수의 도움말이 한글일때, 탭 사용시 나타나는 
#' 매개변수 제안의 오류를 수정하는 패키지로서 RStudio를 이용해 
#' R을 실행하는 환경에서 작동됨.
#' 
#' 그외에 URGS 리포지토리나 KICT 리포지토리에서 제공하는 함수를
#' 손쉽게 설치할 수 있도록 리포지토리 설정을 변경해 주는 함수를 포함.
#' \tabular{ll}{
#' Package: \tab rskrpatch\cr
#' Type: \tab Package\cr
#' Version: \tab 0.1.5\cr
#' Date: \tab 2016-12-18\cr
#' License: \tab GPL-2\cr
#' }
#' @section kview function:
#' View를 사용하여 데이터를 조회할 때 한글이 깨지는 경우 대체 함수로 사용할 수 있는 함수
#' @docType package
#' @name rskrpatch-package
#' @aliases rskrpatch
#' @encoding utf-8
#' @author 박희성 \email{hspark90@@i-fam.net}
#' @keywords package
NULL

.onLoad <- function(lib, pkg)
{
  os = Sys.info()['sysname']
  if (os == "Windows")
  {
    if (exists(".rs.getHelp"))
    {
      adde <- as.call(expression(Encoding(html) <- "UTF-8"))
      f <- body(.rs.getHelp)
      if (f[[14]][[2]] == "match")
      {
        for (i in length(f):14)
          f[[i + 1]] <- f[[i]]
        f[[14]] <- adde[[1]]
      }
      if (f[[15]][[2]] == "match")
      {
        for (i in length(f):15)
          f[[i + 1]] <- f[[i]]
        f[[15]] <- adde[[1]]
      }
      
      body(.rs.getHelp) <<- f
    } else {
      if (exists(".rs.rpc.get_help"))
      {
        adde <- as.call(expression(Encoding(html) <- "UTF-8"))
        f <- body(.rs.rpc.get_help)
        if (f[[9]][[2]] == "match")
        {
          for (i in length(f):9)
            f[[i + 1]] <- f[[i]]
          f[[9]] <- adde[[1]]
        }
        body(.rs.rpc.get_help) <<- f
      }
      if (exists(".rs.rpc.get_completions"))
      {
        f <- body(.rs.rpc.get_completions)
        adde1 <- as.call(expression(Encoding(line) <- "UTF-8"))
        adde2 <-
          as.call(expression(line <- substr(line, 0, cursorPos)))
        adde3 <-
          as.call(expression(line1 <-
                               iconv(line, to = "ASCII//IGNORE")))
        adde4 <-
          as.call(expression(cursorPos <-
                               cursorPos + nchar(line) - nchar(line1)))
        adde5 <- as.call(expression(line <- line1))
        if (f[[2]][[2]] == "roxygen")
        {
          for (i in length(f):2)
            f[[i + 5]] <- f[[i]]
          f[[2]] <- adde1[[1]]
          f[[3]] <- adde2[[1]]
          f[[4]] <- adde3[[1]]
          f[[5]] <- adde4[[1]]
          f[[6]] <- adde5[[1]]
        }
        body(.rs.rpc.get_completions) <<- f
      }
    }
  }
  .repos.base.url <<- c(
    "CRAN" = "http://cran.rstudio.com/",
    "rforge.net" = "http://rforge.net/",
    "R-Forge" = "http://R-Forge.R-project.org",
    "USGSR" = "http://owi.usgs.gov/R",
    "USGSr.github" = "http://usgs-r.github.com",
    "kict.pub" = "http://r.prj.kr/packages",
    "kict.in" = "http://r.prj.kr/pkg"
  )
  set_repos("kict.pub")
}
