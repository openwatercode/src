#' KoreanProjection: the CRS objects of Korean Map Projections
#'
#' \tabular{ll}{
#' Package: \tab KoreanProjection\cr
#' Type: \tab Package\cr
#' Version: \tab 0.1.2\cr
#' Date: \tab 2014-05-09\cr
#' License: \tab GPL-2.0\cr
#' }
#' 대한민국에서 대한민국 영역을 나타낼 때 사용하는 지도 투영법에 대한 모음입니다.
#' 
#' @docType package
#' @name KoreanProjection-package
#' @aliases KoreanProjection
#' @encoding utf-8
#' @author 박희성
#' 
#' Maintainer: 박희성 <\email{hspark90@@i-fam.net}>
#' @keywords package
NULL

#' Local Coordinate - Bessel1841(Korean 1985); Tokoy Datum
#' 
#' Bessel 1841 타원체를 기준으로하는 경위도 좌표체계\cr
#' Korean 1985
#' @usage Proj4.epsg4004
#' Proj4.epsg4162
#' Proj4.Bessel1841
#' Kor.1985
#' @aliases Proj4.epsg4004 Proj4.epsg4162 Proj4.Bessel1841 Kor.1985
#' @export
Proj4.epsg4004 <- sp::CRS("+proj=longlat +ellps=bessel +towgs84=-145.907,505.034,685.756,-1.162,2.347,1.592,6.342 +no_defs") 

#' @export
Proj4.epsg4162 <- Proj4.epsg4004

#' @export
Proj4.Bessel1841 <- Proj4.epsg4004

#' @export
Kor.1985 <- Proj4.epsg4004

#' Global Coordinate - WGS84(Korean 1995)
#' 
#' WGS84 타원체를 기준으로 하는  경위도 좌표체계\cr
#' Korean 1995
#' @usage Proj4.epsg4326
#' Proj4.epsg4166
#' Proj4.WGS84
#' Kor.1995
#' @aliases Proj4.epsg4326 Proj4.epsg4166 Proj4.WGS84 Kor.1995
#' @importFrom sp CRS
#' @export
Proj4.epsg4326 <- sp::CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +no_defs") 

#' @export
Proj4.epsg4166 <- Proj4.epsg4326

#' @export
Proj4.WGS84 <- Proj4.epsg4326

#' @export
Kor.1995 <- Proj4.epsg4326

#' Global Coordinate - GRS80(Korean 2000)
#' 
#' GRS80 타원체를 기준으로 하는 경위도 좌표체계\cr
#' Korean 2000; ITRF2000; ITRF2K
#' @usage Proj4.epsg4019
#' Proj4.epsg4737
#' Proj4.GRS80
#' Kor.ITRF2K
#' @aliases Proj4.epsg4019 Proj4.epsg4737 Proj4.GRS80 Kor.ITRF2K
#' @export
Proj4.epsg4019 <- sp::CRS("+proj=longlat +ellps=GRS80 +no_defs") 

#' @export
Proj4.epsg4737 <- Proj4.epsg4019

#' @export
Proj4.GRS80 <- Proj4.epsg4019

#' @export
Kor.ITRF2K <- Proj4.epsg4019


#' Google Mercator
#' 
#' Google Mercator, 구글지도/빙지도/야후지도/OSM 등 에서 사용중인 좌표계
#' @usage Proj4.epsg3857
#' Proj4.epsg900913
#' Proj4.Google
#' @aliases Proj4.epsg3857 Proj4.epsg900913 Proj4.Google
Proj4.epsg3857 <- sp::CRS(" +proj=merc +a=6378137 +b=6378137 +lat_ts=0.0 +lon_0=0.0 +x_0=0.0 +y_0=0 +k=1.0 +units=m +nadgrids=@null +no_defs") 

#' @export
Proj4.epsg900913 <- Proj4.epsg3857

#' @export
Proj4.Google <- Proj4.epsg3857

#' Plan Coordinate - UTM; UTM52N(WGS84)
#' 
#' 평면직각 좌표체계 UTM 52N 영역
#' @usage Proj4.epsg32652
#' Kor.WGS84.UTM52N
#' @aliases Kor.WGS84.UTM52N
#' @export
Proj4.epsg32652 <- sp::CRS("+proj=utm +zone=52 +datum=WGS84 +ellps=WGS84 +units=m +no_defs")

#' @export
Kor.WGS84.UTM52N <- Proj4.epsg32652

#' Plan Coordinate - UTM; UTM51N(WGS84)
#' 
#' 평면직각 좌표체계 UTM 51N 영역
#' @usage Proj4.epsg32651
#' Kor.WGS84.UTM51N
#' @aliases Kor.WGS84.UTM51N
#' @export
Proj4.epsg32651 <- sp::CRS("+proj=utm +zone=51 +datum=WGS84 +ellps=WGS84 +units=m +no_defs")

#' @export
Kor.WGS84.UTM51N <- Proj4.epsg32651

#' Plan Coordinate - TM EAST(Bessel1841) Before 1923
#' 
#' (관동 대지진 이후에 대한) 보정이 안된 오래된 국립지리원 표준 - 동부원점\cr\cr
#' 베셀1841 타원체를 기준타원체로하고\cr
#' 경도 129도, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -500km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 동부원점\cr\cr
#' @usage Proj4.epsg2096
#' Kor.Bessel1841.TM_EAST
#' @aliases Kor.Bessel1841.TM_EAST
#' @export
Proj4.epsg2096 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=129 +k=1 +x_0=200000 +y_0=500000 +ellps=bessel +units=m +towgs84=-145.907,505.034,685.756,-1.162,2.347,1.592,6.342 +no_defs")

#' @export
Kor.Bessel1841.TM_EAST <- Proj4.epsg2096

#' Plan Coordinate - TM MID(Bessel1841) Before 1923
#' 
#' (관동 대지진 이후에 대한) 보정이 안된 오래된 국립지리원 표준 - 중부원점\cr\cr
#' 베셀1841 타원체를 기준타원체로하고\cr
#' 경도 127도, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -500km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 중부원점\cr\cr
#' @usage Proj4.epsg2097
#' Kor.Bessel1841.TM_MID
#' @aliases Kor.Bessel1841.TM_MID
#' @export
Proj4.epsg2097 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=127 +k=1 +x_0=200000 +y_0=500000 +ellps=bessel +units=m +towgs84=-145.907,505.034,685.756,-1.162,2.347,1.592,6.342 +no_defs")

#' @export
Kor.Bessel1841.TM_MID <- Proj4.epsg2097

#' Plan Coordinate - TM WEST(Bessel1841) Before 1923
#' 
#' (관동 대지진 이후에 대한) 보정이 안된 오래된 국립지리원 표준 - 서부원점\cr\cr
#' 베셀1841 타원체를 기준타원체로하고\cr
#' 경도 125도, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -500km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 서부원점\cr\cr
#' @usage Proj4.epsg2098
#' Kor.Bessel1841.TM_WEST
#' @aliases Kor.Bessel1841.TM_WEST
#' @export
Proj4.epsg2098 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=125 +k=1 +x_0=200000 +y_0=500000 +ellps=bessel +units=m +towgs84=-145.907,505.034,685.756,-1.162,2.347,1.592,6.342 +no_defs")

#' @export
Kor.Bessel1841.TM_WEST <- Proj4.epsg2098

#' Plan Coordinate - TM WEST(Bessel1841) After 1923
#' 
#' (관동 대지진 이후에 대한) 보정된 오래된 국립지리원 표준 - 서부원점\cr\cr
#' 베셀1841 타원체를 기준타원체로하고\cr
#' 경도 125도 10.4초, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -500km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 서부원점\cr\cr
#' @usage Proj4.epsg5173
#' Kor.Bessel1841.TMC_WEST
#' @aliases Kor.Bessel1841.TMC_WEST
#' @export
Proj4.epsg5173 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=125.0028902777 +k=1 +x_0=200000 +y_0=500000 +ellps=bessel +units=m +towgs84=-145.907,505.034,685.756,-1.162,2.347,1.592,6.342 +no_defs")

#' @export
Kor.Bessel1841.TMC_WEST <- Proj4.epsg5173

#' Plan Coordinate - TM MID(Bessel1841) After 1923
#' 
#' (관동 대지진 이후에 대한) 보정된 오래된 국립지리원 표준 - 중부원점\cr\cr
#' 베셀1841 타원체를 기준타원체로하고\cr
#' 경도 127도 10.4초, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -500km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 중부원점\cr\cr
#' @usage Proj4.epsg5174
#' Kor.Bessel1841.TMC_MID
#' @aliases Kor.Bessel1841.TMC_MID
#' @export
Proj4.epsg5174 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=127.0028902777 +k=1 +x_0=200000 +y_0=500000 +ellps=bessel +units=m +towgs84=-145.907,505.034,685.756,-1.162,2.347,1.592,6.342 +no_defs")

#' @export
Kor.Bessel1841.TMC_MID <- Proj4.epsg5174

#' Plan Coordinate - TM Jeju(Bessel1841) After 1923
#' 
#' (관동 대지진 이후에 대한) 보정된 오래된 국립지리원 표준 - 제주원점\cr\cr
#' 베셀1841 타원체를 기준타원체로하고\cr
#' 경도 127도 10.4초, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -550km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 제주원점\cr\cr
#' 제주도에서 TM좌표가 음수가 되는 것을 막기 위해 y축 가상원점을 중부원점과 다르게 설정함
#' @usage Proj4.epsg5175
#' Kor.Bessel1841.TMC_Jeju
#' @aliases Kor.Bessel1841.TMC_Jeju
#' @export
Proj4.epsg5175 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=127.0028902777 +k=1 +x_0=200000 +y_0=550000 +ellps=bessel +units=m +towgs84=-145.907,505.034,685.756,-1.162,2.347,1.592,6.342 +no_defs")

#' @export
Kor.Bessel1841.TMC_Jeju <- Proj4.epsg5175

#' Plan Coordinate - TM EAST(Bessel1841) After 1923
#' 
#' (관동 대지진 이후에 대한) 보정된 오래된 국립지리원 표준 - 동부원점\cr\cr
#' 베셀1841 타원체를 기준타원체로하고\cr
#' 경도 129도 10.4초, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -500km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 동부원점\cr\cr
#' @usage Proj4.epsg5176
#' Kor.Bessel1841.TMC_EAST
#' @aliases Kor.Bessel1841.TMC_EAST
#' @export
Proj4.epsg5176 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=129.0028902777 +k=1 +x_0=200000 +y_0=500000 +ellps=bessel +units=m +towgs84=-145.907,505.034,685.756,-1.162,2.347,1.592,6.342 +no_defs")

#' @export
Kor.Bessel1841.TMC_EAST <- Proj4.epsg5176

#' Plan Coordinate - TM EastSea(Bessel1841) After 1923
#' 
#' (관동 대지진 이후에 대한) 보정된 오래된 국립지리원 표준 - 동해원점\cr\cr
#' 베셀1841 타원체를 기준타원체로하고\cr
#' 경도 131도 10.4초, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -500km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 동해원점\cr\cr
#' @usage Proj4.epsg5177
#' Kor.Bessel1841.TMC_EastSea
#' @aliases Kor.Bessel1841.TMC_EastSea
#' @export
Proj4.epsg5177 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=131.0028902777 +k=1 +x_0=200000 +y_0=500000 +ellps=bessel +units=m +towgs84=-145.907,505.034,685.756,-1.162,2.347,1.592,6.342 +no_defs")

#' @export
Kor.Bessel1841.TMC_EastSea <- Proj4.epsg5177



#' Plan Coordinate - KATEC; UTM-K(Bessel1841)
#' 
#' 새주소 지도에서 사용중인 좌표계\cr\cr
#' 베셀1841 타원체를 기준타원체로하고\cr
#' 경도 127.5도, 위도 38도를 기준점으로 축척계수 0.9996\cr
#' x축의 가상원점을 -1000km, y축의 가상원점을 -2000km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 원점으로 한반도 전체를 나타낼 수 있음\cr\cr
#' KATEC 또는 UTM-K 등으로 불리움
#' @usage Proj4.epsg5178
#' Kor.Bessel1841.UTM_K
#' Kor.Bessel1841.KATEC
#' @aliases Kor.Bessel1841.UTM_K Kor.Bessel1841.KATEC
#' @export
Proj4.epsg5178 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=127.5 +k=0.9996 +x_0=1000000 +y_0=2000000 +ellps=bessel +units=m +towgs84=-145.907,505.034,685.756,-1.162,2.347,1.592,6.342 +no_defs")

#' @export
Kor.Bessel1841.UTM_K <- Proj4.epsg5178

#' @export
Kor.Bessel1841.KATEC <- Proj4.epsg5178

#' Plan Coordinate - KATEC; UTM-K(GRS80)
#' 
#' 네이버 지도에서 사용 중인 좌표계\cr\cr
#' GRS80 타원체를 기준타원체로하고\cr
#' 경도 127.5도, 위도 38도를 기준점으로 축척계수 0.9996\cr
#' x축의 가상원점을 -1000km, y축의 가상원점을 -2000km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 원점으로 한반도 전체를 나타낼 수 있음\cr\cr
#' KATEC 또는 UTM-K 등으로 불리움
#' @usage Proj4.epsg5179
#' Kor.ITRF2K.UTM_K
#' Kor.ITRF2K.KATEC
#' @aliases Kor.ITRF2K.UTM_K Kor.ITRF2K.KATEC
#' @export
Proj4.epsg5179 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=127.5 +k=0.9996 +x_0=1000000 +y_0=2000000 +ellps=GRS80 +units=m +no_defs")

#' @export
Kor.ITRF2K.UTM_K <- Proj4.epsg5179

#' @export
Kor.ITRF2K.KATEC <- Proj4.epsg5179


#' Plan Coordinate - TM WEST(GRS80; falseY=500km)
#' 
#' ITRF2000 제정당시 국립지리원 표준 - 서부원점\cr\cr
#' GRS80 타원체를 기준타원체로하고\cr
#' 경도 125도, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -500km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 서부원점
#' @usage Proj4.epsg5180
#' Kor.ITRF2K.TM_WEST
#' @aliases Kor.ITRF2K.TM_WEST
#' @export
Proj4.epsg5180 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=125 +k=1 +x_0=200000 +y_0=500000 +ellps=GRS80 +units=m +no_defs")

#' @export
Kor.ITRF2K.TM_WEST <- Proj4.epsg5180

#' Plan Coordinate - TM MID(GRS80; falseY=500km)
#' 
#' ITRF2000 제정당시 국립지리원 표준 - 중부원점\cr\cr
#' GRS80 타원체를 기준타원체로하고\cr
#' 경도 127도, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -500km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 중부원점
#' @usage Proj4.epsg5181
#' Kor.ITRF2K.TM_MID
#' @aliases Kor.ITRF2K.TM_MID
#' @export
Proj4.epsg5181 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=127 +k=1 +x_0=200000 +y_0=500000 +ellps=GRS80 +units=m +no_defs")

#' @export
Kor.ITRF2K.TM_MID <- Proj4.epsg5181

#' Plan Coordinate - TM Jeju(GRS80; falseY=500km)
#' 
#' ITRF2000 제정당시 국립지리원 표준 - 제주원점\cr\cr
#' GRS80 타원체를 기준타원체로하고\cr
#' 경도 127도, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -550km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 제주원점\cr\cr
#' 제주도에서 좌표가 음수가 되지 않도록 y축 가상원점만 중부원점과 다르게 설정
#' @usage Proj4.epsg5181a
#' Kor.ITRF2K.TM_Jeju
#' @aliases Kor.ITRF2K.TM_Jeju
#' @export
Proj4.epsg5181a <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=127 +k=1 +x_0=200000 +y_0=550000 +ellps=GRS80 +units=m +no_defs")

#' @export
Kor.ITRF2K.TM_Jeju <- Proj4.epsg5181a

#' Plan Coordinate - TM EAST(GRS80; falseY=500km)
#' 
#' ITRF2000 제정당시 국립지리원 표준 - 동부원점\cr\cr
#' GRS80 타원체를 기준타원체로하고\cr
#' 경도 129도, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -500km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 동부원점\cr\cr
#' @usage Proj4.epsg5183
#' Kor.ITRF2K.TM_EAST
#' @aliases Kor.ITRF2K.TM_EAST
#' @export
Proj4.epsg5183 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=129 +k=1 +x_0=200000 +y_0=500000 +ellps=GRS80 +units=m +no_defs")

#' @export
Kor.ITRF2K.TM_EAST <- Proj4.epsg5183

#' Plan Coordinate - TM EastSea(GRS80; falseY=500km)
#' 
#' ITRF2000 제정당시 국립지리원 표준 - 동해원점\cr\cr
#' GRS80 타원체를 기준타원체로하고\cr
#' 경도 131도, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -500km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 동해원점\cr\cr
#' @usage Proj4.epsg5184
#' Kor.ITRF2K.TM_EastSea
#' @aliases Kor.ITRF2K.TM_EastSea
#' @export
Proj4.epsg5184 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=131 +k=1 +x_0=200000 +y_0=500000 +ellps=GRS80 +units=m +no_defs")

#' @export
Kor.ITRF2K.TM_EastSea <- Proj4.epsg5184



#' Plan Coordinate - TM WEST(GRS80; falseY=600km)
#' 
#' 현재 국립지리원 표준 - 서부원점\cr\cr
#' GRS80 타원체를 기준타원체로하고\cr
#' 경도 125도, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -600km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 서부원점\cr\cr
#' @usage Proj4.epsg5185
#' Kor.ITRF2K.TM6_WEST
#' @aliases Kor.ITRF2K.TM6_WEST
#' @export
Proj4.epsg5185 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=125 +k=1 +x_0=200000 +y_0=600000 +ellps=GRS80 +units=m +no_defs")

#' @export
Kor.ITRF2K.TM6_WEST <- Proj4.epsg5185

#' Plan Coordinate - TM MID(GRS80; falseY=600km)
#' 
#' 현재 국립지리원 표준 - 중부원점\cr\cr
#' GRS80 타원체를 기준타원체로하고\cr
#' 경도 127도, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -600km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 중부원점\cr\cr
#' @usage Proj4.epsg5186
#' Kor.ITRF2K.TM6_MID
#' @aliases Kor.ITRF2K.TM6_MID
#' @export
Proj4.epsg5186 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=127 +k=1 +x_0=200000 +y_0=600000 +ellps=GRS80 +units=m +no_defs")

#' @export
Kor.ITRF2K.TM6_MID <- Proj4.epsg5186


#' Plan Coordinate - TM EAST(GRS80; falseY=600km)
#' 
#' 현재 국립지리원 표준 - 동부원점\cr\cr
#' GRS80 타원체를 기준타원체로하고\cr
#' 경도 129도, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -600km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 동부원점\cr\cr
#' @usage Proj4.epsg5187
#' Kor.ITRF2K.TM6_EAST
#' @aliases Kor.ITRF2K.TM6_EAST
#' @export
Proj4.epsg5187 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=129 +k=1 +x_0=200000 +y_0=600000 +ellps=GRS80 +units=m +no_defs")

#' @export
Kor.ITRF2K.TM6_EAST <- Proj4.epsg5187


#' Plan Coordinate - TM EastSea(GRS80; falseY=600km)
#' 
#' 현재 국립지리원 표준 - 동해원점\cr\cr
#' GRS80 타원체를 기준타원체로하고\cr
#' 경도 131도, 위도 38도를 기준점으로\cr
#' x축의 가상원점을 -200km, y축의 가상원점을 -600km로 설정하여\cr
#' 횡축 메르카토르(Transverse Mercator) 도법을 적용한 동해원점\cr\cr
#' @usage Proj4.epsg5188
#' Kor.ITRF2K.TM6_EastSea
#' @aliases Kor.ITRF2K.TM6_EastSea
#' @export
Proj4.epsg5188 <- sp::CRS("+proj=tmerc +lat_0=38 +lon_0=131 +k=1 +x_0=200000 +y_0=600000 +ellps=GRS80 +units=m +no_defs")

#' @export
Kor.ITRF2K.TM6_EastSea <- Proj4.epsg5188


#' Plan Coordinate - Lambert Convormal Conic Porjection
#' 
#' 기상청에서 사용하는 LCC 좌표계\cr\cr
#' 레이더 자료 결과의 표출에 사용됨\cr
#' @usage Kor.Kma.LCC
#' Kma.LCC
#' @aliases Kma.LCC
#' @export
Kor.Kma.LCC <- CRS("+proj=lcc +lat_1=30 +lat_2=60 +lat_0=38 +lon_0=126 +x_0=430000 +y_0=789000 +a=6371008.77 +b=6371008.77 +units=m +no_defs")

#' @export
Kma.LCC <- Kor.Kma.LCC

#' Azimuthal Equi-Distant Projection; aeqd
#' 
#' 정거방위도법(등거방위도법; 방위정거도법; 방위등거도법)\cr\cr
#' 레이더의 투영에 사용되는 투영법\cr
#' 한 지점을 기준으로 방위각과 거리가 실제와 동일하도록 하는 투영법\cr
#' WGS84 타원체를 기준타원체로 사용\cr
#' @param center_lng 기준점에 대한 WGS84 타원체의 경도
#' @param center_lat 기준점에 대한 WGS84 타원체의 위도
#' @return 주어진 경위도를 기준으로 하는 정거방위도법 객체를 \code{\link[sp:CRS]{CRS}} 형태로 반환
#' @export
Proj4.Radar <- function(center_lng, center_lat) CRS(sprintf("+proj=aeqd +lat_0=%f +lon_0=%f +k=1 +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs", center_lat, center_lng))
